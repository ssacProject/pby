#!/usr/bin/env python3

import rospy

from basics.srv import WordCount, WordCountResponse

def count_words(request):


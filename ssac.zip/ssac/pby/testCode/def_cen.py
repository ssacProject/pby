import cv2
import numpy as np

#cpt = (int(width* 0.5), int(height*0.5))

lines = np.array([[[1, 2, 3, 4]], [[5, 6, 7, 8]], [[9, 10, 11, 12]]])
all_lines = []
count = 0
for line in lines:
    x1 = line[0, 0]
    y1 = line[0, 1]
    x2 = line[0, 2]
    y2 = line[0, 3]
    
    print("count", count)
    count = count +1
    print("line", line)
    all_lines.append([x1,y1,x2,y2])

print("lines", lines)
print("all_lines" , all_lines)

print("1", all_lines[2])

print("[0][3]", all_lines[0][3])

aa = 1
bb = 1

def return2(aa, bb):
    bb = bb + 1
    aa = aa + 2
    return aa, bb

re1, re2 = return2(5, 5)
re3 = return2(1, 1)

print("re1, re2" , re1, re2)
print("re3", re3)

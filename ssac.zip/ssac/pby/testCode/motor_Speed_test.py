import motor_test
import time

print("main")

motor_test.motor_init()
left = 0.3
right = 0.3

motor_test.set_speed(1, left)
motor_test.set_speed(2, right)

time.sleep(2)

motor_test.all_stop()

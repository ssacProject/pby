a = 5
b = 4

if -a < -4:
    print("aa")


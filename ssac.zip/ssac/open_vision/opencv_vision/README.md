# opencv_vision


cap.set(cv2.CAP_PROP_FRAME_WIDTH,640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT,480)

ㅁㅁㅁㅁㅁㅁㅁㅁㅁ
